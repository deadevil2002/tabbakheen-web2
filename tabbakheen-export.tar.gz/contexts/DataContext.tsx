import { useState, useEffect, useCallback, useMemo } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import createContextHook from '@nkzw/create-context-hook';
import {
  Offer,
  Order,
  ProviderRating,
  DriverRating,
  User,
  PaymentMethod,
  PaymentStatus,
  OrderStatus,
  Subscription,
  AppSettings,
  DeliveryMethod,
  DeliveryPaymentMethod,
  ProviderPaymentMethods,
} from '@/types';
import {
  MOCK_OFFERS,
  MOCK_ORDERS,
  MOCK_RATINGS,
  MOCK_DRIVER_RATINGS,
  MOCK_PROVIDERS,
  MOCK_DRIVERS,
  MOCK_SUBSCRIPTIONS,
  MOCK_APP_SETTINGS,
} from '@/mocks/data';
import { generateId, generateOrderNumber, calculateDeliveryFee } from '@/utils/helpers';

const OFFERS_KEY = 'tabbakheen_offers';
const ORDERS_KEY = 'tabbakheen_orders';
const RATINGS_KEY = 'tabbakheen_ratings';
const DRIVER_RATINGS_KEY = 'tabbakheen_driver_ratings';
const USERS_KEY = 'tabbakheen_users';
const SUBSCRIPTIONS_KEY = 'tabbakheen_subscriptions';
const APP_SETTINGS_KEY = 'tabbakheen_app_settings';

export const [DataProvider, useData] = createContextHook(() => {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [ratings, setRatings] = useState<ProviderRating[]>([]);
  const [driverRatings, setDriverRatings] = useState<DriverRating[]>([]);
  const [providers, setProviders] = useState<User[]>([]);
  const [drivers, setDrivers] = useState<User[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings>(MOCK_APP_SETTINGS);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [offersData, ordersData, ratingsData, driverRatingsData, usersData, subsData, settingsData] = await Promise.all([
        AsyncStorage.getItem(OFFERS_KEY),
        AsyncStorage.getItem(ORDERS_KEY),
        AsyncStorage.getItem(RATINGS_KEY),
        AsyncStorage.getItem(DRIVER_RATINGS_KEY),
        AsyncStorage.getItem(USERS_KEY),
        AsyncStorage.getItem(SUBSCRIPTIONS_KEY),
        AsyncStorage.getItem(APP_SETTINGS_KEY),
      ]);

      const loadedOffers = offersData ? JSON.parse(offersData) : MOCK_OFFERS;
      const loadedOrders = ordersData ? JSON.parse(ordersData) : MOCK_ORDERS;
      const loadedRatings = ratingsData ? JSON.parse(ratingsData) : MOCK_RATINGS;
      const loadedDriverRatings = driverRatingsData ? JSON.parse(driverRatingsData) : MOCK_DRIVER_RATINGS;
      const loadedUsers: User[] = usersData ? JSON.parse(usersData) : [...MOCK_PROVIDERS, ...MOCK_DRIVERS];
      const loadedSubs = subsData ? JSON.parse(subsData) : MOCK_SUBSCRIPTIONS;
      const loadedSettings = settingsData ? JSON.parse(settingsData) : MOCK_APP_SETTINGS;

      if (!offersData) await AsyncStorage.setItem(OFFERS_KEY, JSON.stringify(MOCK_OFFERS));
      if (!ordersData) await AsyncStorage.setItem(ORDERS_KEY, JSON.stringify(MOCK_ORDERS));
      if (!ratingsData) await AsyncStorage.setItem(RATINGS_KEY, JSON.stringify(MOCK_RATINGS));
      if (!driverRatingsData) await AsyncStorage.setItem(DRIVER_RATINGS_KEY, JSON.stringify(MOCK_DRIVER_RATINGS));
      if (!subsData) await AsyncStorage.setItem(SUBSCRIPTIONS_KEY, JSON.stringify(MOCK_SUBSCRIPTIONS));
      if (!settingsData) await AsyncStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(MOCK_APP_SETTINGS));

      setOffers(loadedOffers);
      setOrders(loadedOrders);
      setRatings(loadedRatings);
      setDriverRatings(loadedDriverRatings);
      setProviders(loadedUsers.filter((u: User) => u.role === 'provider'));
      setDrivers(loadedUsers.filter((u: User) => u.role === 'driver'));
      setSubscriptions(loadedSubs);
      setAppSettings(loadedSettings);
    } catch (e) {
      console.log('Error loading data:', e);
      setOffers(MOCK_OFFERS);
      setOrders(MOCK_ORDERS);
      setRatings(MOCK_RATINGS);
      setDriverRatings(MOCK_DRIVER_RATINGS);
      setProviders(MOCK_PROVIDERS);
      setDrivers(MOCK_DRIVERS);
      setSubscriptions(MOCK_SUBSCRIPTIONS);
      setAppSettings(MOCK_APP_SETTINGS);
    } finally {
      setIsLoading(false);
    }
  };

  const saveOffers = async (updated: Offer[]) => {
    setOffers(updated);
    await AsyncStorage.setItem(OFFERS_KEY, JSON.stringify(updated));
  };

  const saveOrders = async (updated: Order[]) => {
    setOrders(updated);
    await AsyncStorage.setItem(ORDERS_KEY, JSON.stringify(updated));
  };

  const saveRatings = async (updated: ProviderRating[]) => {
    setRatings(updated);
    await AsyncStorage.setItem(RATINGS_KEY, JSON.stringify(updated));
  };

  const saveDriverRatings = async (updated: DriverRating[]) => {
    setDriverRatings(updated);
    await AsyncStorage.setItem(DRIVER_RATINGS_KEY, JSON.stringify(updated));
  };

  const saveSubscriptions = async (updated: Subscription[]) => {
    setSubscriptions(updated);
    await AsyncStorage.setItem(SUBSCRIPTIONS_KEY, JSON.stringify(updated));
  };

  const createOffer = useCallback(
    async (offer: Omit<Offer, 'id' | 'createdAt'>) => {
      const newOffer: Offer = {
        ...offer,
        id: generateId(),
        createdAt: new Date().toISOString(),
      };
      const updated = [newOffer, ...offers];
      await saveOffers(updated);
      return newOffer;
    },
    [offers],
  );

  const updateOffer = useCallback(
    async (id: string, updates: Partial<Offer>) => {
      const updated = offers.map((o) => (o.id === id ? { ...o, ...updates } : o));
      await saveOffers(updated);
    },
    [offers],
  );

  const deleteOffer = useCallback(
    async (id: string) => {
      const updated = offers.filter((o) => o.id !== id);
      await saveOffers(updated);
    },
    [offers],
  );

  const createOrder = useCallback(
    async (order: {
      customerUid: string;
      providerUid: string;
      offerId: string;
      offerTitleSnapshot: string;
      priceSnapshot: number;
      note: string;
      paymentMethod: PaymentMethod;
    }) => {
      const now = new Date().toISOString();

      const provider = providers.find((p) => p.uid === order.providerUid);
      const usersData = await AsyncStorage.getItem(USERS_KEY);
      const allUsers: User[] = usersData ? JSON.parse(usersData) : [];
      const customer = allUsers.find((u) => u.uid === order.customerUid);

      const newOrder: Order = {
        id: generateId(),
        orderNumber: generateOrderNumber(),
        customerUid: order.customerUid,
        providerUid: order.providerUid,
        driverUid: null,
        offerId: order.offerId,
        offerTitleSnapshot: order.offerTitleSnapshot,
        priceSnapshot: order.priceSnapshot,
        deliveryFee: 0,
        totalAmount: order.priceSnapshot,
        deliveryMethod: null,
        paymentMethod: order.paymentMethod,
        deliveryPaymentMethod: null,
        paymentStatus: 'unpaid',
        status: 'pending',
        providerComment: '',
        statusReason: '',
        driverStatus: '',
        transactionId: '',
        paidAt: null,
        ratingSubmitted: false,
        driverRatingSubmitted: false,
        note: order.note,
        deliveryNotes: '',
        stcPayProofImageUrl: '',
        stcPayProofNote: '',
        paymentReference: '',
        providerLat: provider?.location?.lat ?? null,
        providerLng: provider?.location?.lng ?? null,
        customerLat: customer?.location?.lat ?? null,
        customerLng: customer?.location?.lng ?? null,
        pickupAddress: provider?.address ?? '',
        dropoffAddress: customer?.address ?? '',
        createdAt: now,
        updatedAt: now,
      };
      const updated = [newOrder, ...orders];
      await saveOrders(updated);
      console.log('Order created:', newOrder.id, 'Number:', newOrder.orderNumber, 'Payment:', order.paymentMethod);
      return newOrder;
    },
    [orders],
  );

  const updateOrderStatus = useCallback(
    async (orderId: string, status: OrderStatus, comment?: string, reason?: string) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;

        const updates: Partial<Order> = {
          status,
          updatedAt: now,
        };

        if (comment) {
          updates.providerComment = comment;
        }

        if (reason) {
          updates.statusReason = reason;
        }

        if (status === 'delivered' && o.paymentMethod === 'cod') {
          updates.paymentStatus = 'paid';
          updates.paidAt = now;
        }

        if (status === 'cancelled') {
          if (o.paymentStatus === 'paid') {
            updates.paymentStatus = 'refunded';
          }
        }

        return { ...o, ...updates };
      });
      await saveOrders(updated);
      console.log('Order status updated:', orderId, '->', status);
    },
    [orders],
  );

  const submitPaymentProof = useCallback(
    async (orderId: string, proofImageUrl: string, proofNote: string, paymentReference?: string) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;
        return {
          ...o,
          stcPayProofImageUrl: proofImageUrl,
          stcPayProofNote: proofNote,
          paymentReference: paymentReference ?? o.paymentReference,
          paymentStatus: 'proof_sent' as PaymentStatus,
          updatedAt: now,
        };
      });
      await saveOrders(updated);
      console.log('Payment proof submitted for order:', orderId);
    },
    [orders],
  );

  const confirmPayment = useCallback(
    async (orderId: string) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;
        return {
          ...o,
          paymentStatus: 'paid_confirmed' as PaymentStatus,
          paidAt: now,
          updatedAt: now,
        };
      });
      await saveOrders(updated);
      console.log('Payment confirmed for order:', orderId);
    },
    [orders],
  );

  const rejectPayment = useCallback(
    async (orderId: string) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;
        return {
          ...o,
          paymentStatus: 'payment_rejected' as PaymentStatus,
          updatedAt: now,
        };
      });
      await saveOrders(updated);
      console.log('Payment rejected for order:', orderId);
    },
    [orders],
  );

  const setDeliveryMethod = useCallback(
    async (orderId: string, method: DeliveryMethod, deliveryNotes?: string) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;

        const updates: Partial<Order> = {
          deliveryMethod: method,
          updatedAt: now,
        };

        if (deliveryNotes) {
          updates.deliveryNotes = deliveryNotes;
        }

        if (method === 'self_pickup') {
          updates.deliveryFee = 0;
          updates.totalAmount = o.priceSnapshot;
          updates.deliveryPaymentMethod = null;
          updates.driverUid = null;
        }

        return { ...o, ...updates };
      });
      await saveOrders(updated);
      console.log('Delivery method set:', orderId, '->', method);
    },
    [orders],
  );

  const assignDriver = useCallback(
    async (orderId: string, driverUid: string, deliveryFee?: number, deliveryPaymentMethod?: DeliveryPaymentMethod) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;

        const fee = deliveryFee ?? 0;
        return {
          ...o,
          driverUid,
          deliveryMethod: 'driver_delivery' as DeliveryMethod,
          deliveryFee: fee,
          totalAmount: o.priceSnapshot + fee,
          deliveryPaymentMethod: deliveryPaymentMethod ?? ('cod' as DeliveryPaymentMethod),
          status: 'assigned_to_driver' as OrderStatus,
          driverStatus: 'assigned',
          updatedAt: now,
        };
      });
      await saveOrders(updated);
      console.log('Driver assigned:', driverUid, 'to order:', orderId, 'fee:', deliveryFee);
    },
    [orders],
  );

  const updateDriverStatus = useCallback(
    async (orderId: string, driverStatus: string, orderStatus: OrderStatus) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;

        const updates: Partial<Order> = {
          driverStatus,
          status: orderStatus,
          updatedAt: now,
        };

        if (orderStatus === 'delivered' && o.paymentMethod === 'cod') {
          updates.paymentStatus = 'paid';
          updates.paidAt = now;
        }

        return { ...o, ...updates };
      });
      await saveOrders(updated);
      console.log('Driver status updated:', orderId, '->', driverStatus);
    },
    [orders],
  );

  const markSelfPickupDelivered = useCallback(
    async (orderId: string) => {
      const now = new Date().toISOString();
      const updated = orders.map((o) => {
        if (o.id !== orderId) return o;
        const updates: Partial<Order> = {
          status: 'delivered' as OrderStatus,
          updatedAt: now,
        };
        if (o.paymentMethod === 'cod') {
          updates.paymentStatus = 'paid';
          updates.paidAt = now;
        }
        return { ...o, ...updates };
      });
      await saveOrders(updated);
      console.log('Self pickup delivered:', orderId);
    },
    [orders],
  );

  const submitRating = useCallback(
    async (rating: Omit<ProviderRating, 'id' | 'createdAt'>) => {
      const newRating: ProviderRating = {
        ...rating,
        id: generateId(),
        createdAt: new Date().toISOString(),
      };
      const updatedRatings = [newRating, ...ratings];
      await saveRatings(updatedRatings);

      const updatedOrders = orders.map((o) =>
        o.id === rating.orderId ? { ...o, ratingSubmitted: true } : o,
      );
      await saveOrders(updatedOrders);

      const providerRatings = updatedRatings.filter(
        (r) => r.providerUid === rating.providerUid,
      );
      const avg =
        providerRatings.reduce((sum, r) => sum + r.stars, 0) / providerRatings.length;

      const usersData = await AsyncStorage.getItem(USERS_KEY);
      if (usersData) {
        const users: User[] = JSON.parse(usersData);
        const updatedUsers = users.map((u) =>
          u.uid === rating.providerUid
            ? { ...u, ratingAverage: Math.round(avg * 10) / 10, ratingCount: providerRatings.length }
            : u,
        );
        await AsyncStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
        setProviders(updatedUsers.filter((u) => u.role === 'provider'));
      }

      return newRating;
    },
    [ratings, orders],
  );

  const submitDriverRating = useCallback(
    async (rating: Omit<DriverRating, 'id' | 'createdAt'>) => {
      const newRating: DriverRating = {
        ...rating,
        id: generateId(),
        createdAt: new Date().toISOString(),
      };
      const updatedRatings = [newRating, ...driverRatings];
      await saveDriverRatings(updatedRatings);

      const updatedOrders = orders.map((o) =>
        o.id === rating.orderId ? { ...o, driverRatingSubmitted: true } : o,
      );
      await saveOrders(updatedOrders);

      const driverAllRatings = updatedRatings.filter(
        (r) => r.driverUid === rating.driverUid,
      );
      const avg =
        driverAllRatings.reduce((sum, r) => sum + r.stars, 0) / driverAllRatings.length;

      const usersData = await AsyncStorage.getItem(USERS_KEY);
      if (usersData) {
        const users: User[] = JSON.parse(usersData);
        const updatedUsers = users.map((u) =>
          u.uid === rating.driverUid
            ? { ...u, ratingAverage: Math.round(avg * 10) / 10, ratingCount: driverAllRatings.length }
            : u,
        );
        await AsyncStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
        setDrivers(updatedUsers.filter((u) => u.role === 'driver'));
      }

      return newRating;
    },
    [driverRatings, orders],
  );

  const getProviderById = useCallback(
    (uid: string): User | undefined => {
      return providers.find((p) => p.uid === uid);
    },
    [providers],
  );

  const getDriverById = useCallback(
    (uid: string): User | undefined => {
      return drivers.find((d) => d.uid === uid);
    },
    [drivers],
  );

  const getOffersByProvider = useCallback(
    (providerUid: string): Offer[] => {
      return offers.filter((o) => o.providerUid === providerUid);
    },
    [offers],
  );

  const getOrdersByCustomer = useCallback(
    (customerUid: string): Order[] => {
      return orders.filter((o) => o.customerUid === customerUid);
    },
    [orders],
  );

  const getOrdersByProvider = useCallback(
    (providerUid: string): Order[] => {
      return orders.filter((o) => o.providerUid === providerUid);
    },
    [orders],
  );

  const getOrdersByDriver = useCallback(
    (driverUid: string): Order[] => {
      return orders.filter((o) => o.driverUid === driverUid);
    },
    [orders],
  );

  const getAvailableDeliveries = useCallback(
    (): Order[] => {
      return orders.filter(
        (o) => o.status === 'ready_for_pickup' && o.deliveryMethod === 'driver_delivery' && !o.driverUid,
      );
    },
    [orders],
  );

  const getAvailableDrivers = useCallback(
    (): User[] => {
      return drivers.filter((d) => d.isAvailable === true);
    },
    [drivers],
  );

  const getRatingsByProvider = useCallback(
    (providerUid: string): ProviderRating[] => {
      return ratings.filter((r) => r.providerUid === providerUid);
    },
    [ratings],
  );

  const getRatingsByDriver = useCallback(
    (driverUid: string): DriverRating[] => {
      return driverRatings.filter((r) => r.driverUid === driverUid);
    },
    [driverRatings],
  );

  const getSubscription = useCallback(
    (providerUid: string): Subscription | undefined => {
      return subscriptions.find((s) => s.providerUid === providerUid);
    },
    [subscriptions],
  );

  const isProviderSubscriptionValid = useCallback(
    (providerUid: string): boolean => {
      const sub = subscriptions.find((s) => s.providerUid === providerUid);
      if (!sub) return false;
      if (sub.status === 'trialing') {
        return new Date(sub.trialEndsAt).getTime() > Date.now();
      }
      if (sub.status === 'active') {
        return new Date(sub.currentPeriodEnd).getTime() > Date.now();
      }
      return false;
    },
    [subscriptions],
  );

  const createSubscription = useCallback(
    async (providerUid: string) => {
      const now = new Date();
      const trialEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      const newSub: Subscription = {
        id: generateId(),
        providerUid,
        planId: 'tabbakheen_basic',
        status: 'trialing',
        trialEndsAt: trialEnd.toISOString(),
        currentPeriodStart: now.toISOString(),
        currentPeriodEnd: trialEnd.toISOString(),
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      };
      const updated = [...subscriptions, newSub];
      await saveSubscriptions(updated);
      console.log('Subscription created for provider:', providerUid, 'trial ends:', trialEnd.toISOString());
      return newSub;
    },
    [subscriptions],
  );

  const updateProviderPaymentMethods = useCallback(
    async (providerUid: string, paymentMethods: ProviderPaymentMethods) => {
      const usersData = await AsyncStorage.getItem(USERS_KEY);
      if (usersData) {
        const users: User[] = JSON.parse(usersData);
        const updatedUsers = users.map((u) =>
          u.uid === providerUid ? { ...u, paymentMethods } : u,
        );
        await AsyncStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
        setProviders(updatedUsers.filter((u) => u.role === 'provider'));
      }
      console.log('Provider payment methods updated:', providerUid);
    },
    [],
  );

  const updateDriverAvailability = useCallback(
    async (driverUid: string, isAvailable: boolean) => {
      const usersData = await AsyncStorage.getItem(USERS_KEY);
      if (usersData) {
        const users: User[] = JSON.parse(usersData);
        const updatedUsers = users.map((u) =>
          u.uid === driverUid ? { ...u, isAvailable } : u,
        );
        await AsyncStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));
        setDrivers(updatedUsers.filter((u) => u.role === 'driver'));
      }
      console.log('Driver availability updated:', driverUid, '->', isAvailable);
    },
    [],
  );

  const computeDeliveryFee = useCallback(
    (providerUid: string, customerLat?: number, customerLng?: number): number => {
      const provider = providers.find((p) => p.uid === providerUid);
      if (!provider?.location || !customerLat || !customerLng) {
        return appSettings.deliveryPricing.baseFee;
      }
      return calculateDeliveryFee(
        provider.location.lat,
        provider.location.lng,
        customerLat,
        customerLng,
        appSettings.deliveryPricing,
      );
    },
    [providers, appSettings],
  );

  const activeProviders = useMemo(() => {
    return providers.filter((p) => isProviderSubscriptionValid(p.uid));
  }, [providers, isProviderSubscriptionValid]);

  const availableOffers = useMemo(() => {
    const validProviderUids = new Set(activeProviders.map((p) => p.uid));
    return offers.filter((o) => o.isAvailable && validProviderUids.has(o.providerUid));
  }, [offers, activeProviders]);

  return {
    offers,
    orders,
    ratings,
    driverRatings,
    providers,
    drivers,
    subscriptions,
    appSettings,
    activeProviders,
    availableOffers,
    isLoading,
    createOffer,
    updateOffer,
    deleteOffer,
    createOrder,
    updateOrderStatus,
    submitPaymentProof,
    confirmPayment,
    rejectPayment,
    setDeliveryMethod,
    assignDriver,
    updateDriverStatus,
    markSelfPickupDelivered,
    submitRating,
    submitDriverRating,
    getProviderById,
    getDriverById,
    getOffersByProvider,
    getOrdersByCustomer,
    getOrdersByProvider,
    getOrdersByDriver,
    getAvailableDeliveries,
    getAvailableDrivers,
    getRatingsByProvider,
    getRatingsByDriver,
    getSubscription,
    isProviderSubscriptionValid,
    createSubscription,
    updateProviderPaymentMethods,
    updateDriverAvailability,
    computeDeliveryFee,
  };
});

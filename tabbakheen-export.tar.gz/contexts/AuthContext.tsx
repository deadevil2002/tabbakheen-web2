import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import createContextHook from '@nkzw/create-context-hook';
import { User, UserRole } from '@/types';
import { MOCK_CUSTOMER, MOCK_PROVIDERS, MOCK_DRIVERS } from '@/mocks/data';
import { generateId } from '@/utils/helpers';

const AUTH_KEY = 'tabbakheen_auth';
const USERS_KEY = 'tabbakheen_users';

export const [AuthProvider, useAuth] = createContextHook(() => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadSession();
  }, []);

  const loadSession = async () => {
    try {
      const [sessionData, usersData] = await Promise.all([
        AsyncStorage.getItem(AUTH_KEY),
        AsyncStorage.getItem(USERS_KEY),
      ]);

      if (!usersData) {
        const allUsers = [MOCK_CUSTOMER, ...MOCK_PROVIDERS, ...MOCK_DRIVERS];
        await AsyncStorage.setItem(USERS_KEY, JSON.stringify(allUsers));
      }

      if (sessionData) {
        const uid = sessionData;
        const users = usersData ? JSON.parse(usersData) : [MOCK_CUSTOMER, ...MOCK_PROVIDERS, ...MOCK_DRIVERS];
        const found = users.find((u: User) => u.uid === uid);
        if (found) {
          setUser(found);
        }
      }
    } catch (e) {
      console.log('Error loading session:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const login = useCallback(async (email: string, _password: string): Promise<User> => {
    const usersData = await AsyncStorage.getItem(USERS_KEY);
    const users: User[] = usersData ? JSON.parse(usersData) : [MOCK_CUSTOMER, ...MOCK_PROVIDERS, ...MOCK_DRIVERS];
    const found = users.find((u) => u.email === email);

    if (!found) {
      throw new Error('USER_NOT_FOUND');
    }

    await AsyncStorage.setItem(AUTH_KEY, found.uid);
    setUser(found);
    return found;
  }, []);

  const register = useCallback(
    async (data: {
      email: string;
      password: string;
      displayName: string;
      phone: string;
      role: UserRole;
    }): Promise<User> => {
      const usersData = await AsyncStorage.getItem(USERS_KEY);
      const users: User[] = usersData ? JSON.parse(usersData) : [MOCK_CUSTOMER, ...MOCK_PROVIDERS, ...MOCK_DRIVERS];

      const exists = users.find((u) => u.email === data.email);
      if (exists) {
        throw new Error('EMAIL_EXISTS');
      }

      const newUser: User = {
        uid: generateId(),
        email: data.email,
        displayName: data.displayName,
        phone: data.phone,
        role: data.role,
        photoUrl: '',
        socialLink: '',
        location: data.role !== 'customer' ? { lat: 24.7136, lng: 46.6753 } : null,
        address: '',
        ratingAverage: 0,
        ratingCount: 0,
        fcmToken: '',
        createdAt: new Date().toISOString(),
      };

      users.push(newUser);
      await AsyncStorage.setItem(USERS_KEY, JSON.stringify(users));
      await AsyncStorage.setItem(AUTH_KEY, newUser.uid);
      setUser(newUser);
      return newUser;
    },
    [],
  );

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(AUTH_KEY);
    setUser(null);
  }, []);

  const updateUser = useCallback(
    async (updates: Partial<User>) => {
      if (!user) return;
      const usersData = await AsyncStorage.getItem(USERS_KEY);
      const users: User[] = usersData ? JSON.parse(usersData) : [];
      const idx = users.findIndex((u) => u.uid === user.uid);
      if (idx >= 0) {
        users[idx] = { ...users[idx], ...updates };
        await AsyncStorage.setItem(USERS_KEY, JSON.stringify(users));
        setUser(users[idx]);
      }
    },
    [user],
  );

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    updateUser,
  };
});

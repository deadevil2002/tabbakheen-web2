import React, { useMemo, useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Platform,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { Star, MapPin, Navigation } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { useLocale } from '@/contexts/LocaleContext';
import { useData } from '@/contexts/DataContext';
import { useAuth } from '@/contexts/AuthContext';
import { calculateDistance, formatDistance } from '@/utils/helpers';
import { User } from '@/types';

let MapView: any = null;
let Marker: any = null;

try {
  const maps = require('react-native-maps');
  MapView = maps.default;
  Marker = maps.Marker;
} catch {
  console.log('react-native-maps not available');
}

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function CustomerMapScreen() {
  const router = useRouter();
  const { t, isRTL, locale } = useLocale();
  const { providers } = useData();
  const { user } = useAuth();

  const [selectedProvider, setSelectedProvider] = useState<User | null>(null);

  const userLocation = user?.location || { lat: 24.7136, lng: 46.6753 };

  const sortedProviders = useMemo(() => {
    return [...providers]
      .map((p) => ({
        ...p,
        distance: p.location
          ? calculateDistance(userLocation.lat, userLocation.lng, p.location.lat, p.location.lng)
          : 999,
      }))
      .sort((a, b) => a.distance - b.distance);
  }, [providers, userLocation]);

  const handleProviderPress = useCallback((provider: User) => {
    setSelectedProvider(provider);
  }, []);

  const handleViewProfile = useCallback(
    (uid: string) => {
      router.push(`/(customer)/home/provider/${uid}` as any);
    },
    [],
  );

  const initialRegion = {
    latitude: userLocation.lat,
    longitude: userLocation.lng,
    latitudeDelta: 0.08,
    longitudeDelta: 0.08,
  };

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.headerSafe}>
        <Text style={[styles.headerTitle, isRTL && styles.rtlText]}>{t('nearbyProviders')}</Text>
      </SafeAreaView>

      <View style={styles.mapContainer}>
        {MapView && Platform.OS !== 'web' ? (
          <MapView
            style={styles.map}
            initialRegion={initialRegion}
            showsUserLocation
            showsMyLocationButton
          >
            {sortedProviders.map((provider) =>
              provider.location ? (
                <Marker
                  key={provider.uid}
                  coordinate={{
                    latitude: provider.location.lat,
                    longitude: provider.location.lng,
                  }}
                  title={provider.displayName}
                  onPress={() => handleProviderPress(provider)}
                />
              ) : null,
            )}
          </MapView>
        ) : (
          <View style={styles.mapPlaceholder}>
            <Navigation size={48} color={Colors.primary} />
            <Text style={styles.mapPlaceholderText}>
              {locale === 'ar' ? 'الخريطة متاحة على الجوال' : 'Map available on mobile'}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.listContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.listScroll}
        >
          {sortedProviders.map((provider) => {
            const dist = provider.location
              ? calculateDistance(
                  userLocation.lat,
                  userLocation.lng,
                  provider.location.lat,
                  provider.location.lng,
                )
              : 0;
            return (
              <Pressable
                key={provider.uid}
                style={({ pressed }) => [
                  styles.providerCard,
                  selectedProvider?.uid === provider.uid && styles.providerCardSelected,
                  pressed && styles.cardPressed,
                ]}
                onPress={() => handleViewProfile(provider.uid)}
              >
                <Image
                  source={{ uri: provider.photoUrl }}
                  style={styles.providerAvatar}
                  contentFit="cover"
                />
                <View style={styles.providerInfo}>
                  <Text style={[styles.providerName, isRTL && styles.rtlText]} numberOfLines={1}>
                    {provider.displayName}
                  </Text>
                  <View style={[styles.metaRow, isRTL && styles.rowRTL]}>
                    <Star size={12} color={Colors.star} fill={Colors.star} />
                    <Text style={styles.metaText}>{provider.ratingAverage.toFixed(1)}</Text>
                  </View>
                  <View style={[styles.metaRow, isRTL && styles.rowRTL]}>
                    <MapPin size={12} color={Colors.textTertiary} />
                    <Text style={styles.metaText}>{formatDistance(dist, locale)}</Text>
                  </View>
                </View>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  headerSafe: {
    backgroundColor: Colors.surface,
    paddingHorizontal: 20,
    paddingBottom: 12,
    zIndex: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '800' as const,
    color: Colors.text,
    marginTop: 8,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  mapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.surfaceSecondary,
    gap: 12,
  },
  mapPlaceholderText: {
    fontSize: 15,
    color: Colors.textSecondary,
  },
  listContainer: {
    backgroundColor: Colors.surface,
    paddingVertical: 16,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: Colors.shadow.color,
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 4,
  },
  listScroll: {
    paddingHorizontal: 16,
  },
  providerCard: {
    width: SCREEN_WIDTH * 0.55,
    backgroundColor: Colors.background,
    borderRadius: 16,
    padding: 14,
    marginRight: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  providerCardSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primaryFaded,
  },
  cardPressed: {
    opacity: 0.9,
  },
  providerAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  providerInfo: {
    flex: 1,
  },
  providerName: {
    fontSize: 14,
    fontWeight: '700' as const,
    color: Colors.text,
    marginBottom: 4,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 2,
  },
  rowRTL: {
    flexDirection: 'row-reverse',
  },
  metaText: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  rtlText: {
    textAlign: 'right',
    writingDirection: 'rtl',
  },
});

import React, { useMemo, useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import { Linking } from 'react-native';
import { ArrowLeft, ArrowRight, CreditCard, Banknote, Building2, Truck, Phone, Copy, PackageCheck, Star, MessageCircle, Upload, FileCheck, CheckCircle2, XCircle } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { commonStyles as cs } from '@/constants/sharedStyles';
import { useLocale } from '@/contexts/LocaleContext';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { OrderStatusBadge } from '@/components/OrderStatusBadge';
import { RatingStars } from '@/components/RatingStars';
import { formatPrice, formatDate, getPaymentMethodColor, getPaymentStatusColor, calculateDistance, formatDistance } from '@/utils/helpers';
import { User } from '@/types';

export default function CustomerOrderDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t, isRTL, locale } = useLocale();
  const { user } = useAuth();
  const { orders, getProviderById, getDriverById, getAvailableDrivers, submitRating, submitDriverRating, submitPaymentProof, setDeliveryMethod, assignDriver, markSelfPickupDelivered, computeDeliveryFee } = useData();

  const order = useMemo(() => orders.find((o) => o.id === id), [orders, id]);
  const provider = useMemo(() => (order ? getProviderById(order.providerUid) : undefined), [order, getProviderById]);
  const driver = useMemo(() => (order?.driverUid ? getDriverById(order.driverUid) : undefined), [order, getDriverById]);
  const availableDrivers = useMemo(() => getAvailableDrivers(), [getAvailableDrivers]);

  const [providerStars, setProviderStars] = useState<number>(0);
  const [providerComment, setProviderComment] = useState<string>('');
  const [driverStars, setDriverStars] = useState<number>(0);
  const [driverComment, setDriverComment] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showDriverSelection, setShowDriverSelection] = useState<boolean>(false);
  const [showPaymentProof, setShowPaymentProof] = useState<boolean>(false);
  const [proofImageUrl, setProofImageUrl] = useState<string>('');
  const [proofNote, setProofNote] = useState<string>('');
  const [paymentRef, setPaymentRef] = useState<string>('');

  const canRateProvider = order?.status === 'delivered' && !order?.ratingSubmitted;
  const canRateDriver = order?.status === 'delivered' && !order?.driverRatingSubmitted && !!order?.driverUid;
  const canChooseDelivery = order?.status === 'ready_for_pickup' && !order?.deliveryMethod;
  const canSubmitProof = order && (order.paymentMethod === 'stc_pay' || order.paymentMethod === 'bank_transfer') && order.paymentStatus !== 'paid' && order.paymentStatus !== 'paid_confirmed' && order.paymentStatus !== 'proof_sent' && order.status !== 'rejected' && order.status !== 'cancelled';
  const hasProofSent = order?.paymentStatus === 'proof_sent';
  const isPaymentRejected = order?.paymentStatus === 'payment_rejected';

  const estimatedFee = useMemo(() => {
    if (!order || !provider) return 0;
    return computeDeliveryFee(order.providerUid, user?.location?.lat, user?.location?.lng);
  }, [order, provider, user, computeDeliveryFee]);

  const BackIcon = isRTL ? ArrowRight : ArrowLeft;

  const handleCopy = useCallback(async (text: string) => {
    try {
      if (Platform.OS === 'web') { await navigator.clipboard.writeText(text); } else { await Clipboard.setStringAsync(text); }
      Alert.alert(t('success'), t('copied'));
    } catch { console.log('Copy failed'); }
  }, [t]);

  const handleSelfPickup = useCallback(async () => {
    if (!order) return;
    await setDeliveryMethod(order.id, 'self_pickup');
    Alert.alert(t('success'), locale === 'ar' ? 'تم اختيار الاستلام الذاتي' : 'Self pickup selected');
  }, [order, setDeliveryMethod, t, locale]);

  const handleSelectDriver = useCallback(async (selectedDriver: User) => {
    if (!order) return;
    const fee = computeDeliveryFee(order.providerUid, user?.location?.lat, user?.location?.lng);
    Alert.alert(t('chooseDriver'), `${selectedDriver.displayName}\n${t('deliveryFee')}: ${formatPrice(fee, locale)}`, [
      { text: t('cancel'), style: 'cancel' },
      { text: t('confirm'), onPress: async () => { await assignDriver(order.id, selectedDriver.uid, fee, 'cod'); setShowDriverSelection(false); Alert.alert(t('success'), t('driverSelected')); } },
    ]);
  }, [order, computeDeliveryFee, user, assignDriver, t, locale]);

  const handleSubmitPaymentProof = useCallback(async () => {
    if (!order) return;
    if (!proofImageUrl.trim() && !proofNote.trim()) { Alert.alert(t('error'), locale === 'ar' ? 'يرجى إضافة صورة الإثبات أو ملاحظة' : 'Please add proof image or a note'); return; }
    setIsSubmitting(true);
    try { await submitPaymentProof(order.id, proofImageUrl.trim(), proofNote.trim(), paymentRef.trim()); Alert.alert(t('success'), t('proofSent')); setShowPaymentProof(false); setProofImageUrl(''); setProofNote(''); setPaymentRef(''); }
    catch { Alert.alert(t('error'), t('error')); }
    finally { setIsSubmitting(false); }
  }, [order, proofImageUrl, proofNote, paymentRef, submitPaymentProof, t, locale]);

  const handleWhatsAppProof = useCallback(() => {
    if (!order || !provider) return;
    const whatsappPhone = provider.paymentMethods?.stcPay?.phone || provider.phone;
    const cleanPhone = whatsappPhone.replace(/[^0-9]/g, '');
    const message = locale === 'ar'
      ? `إثبات دفع - طلب رقم: ${order.orderNumber}\nالمبلغ: ${order.priceSnapshot} ر.س\nطريقة الدفع: ${order.paymentMethod === 'stc_pay' ? 'STC Pay' : 'تحويل بنكي'}`
      : `Payment Proof - Order: ${order.orderNumber}\nAmount: ${order.priceSnapshot} SAR\nPayment: ${order.paymentMethod === 'stc_pay' ? 'STC Pay' : 'Bank Transfer'}`;
    Linking.openURL(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`).catch(() => console.log('Cannot open WhatsApp'));
  }, [order, provider, locale]);

  const handleSelfPickupDelivered = useCallback(async () => {
    if (!order) return;
    Alert.alert(t('confirm'), locale === 'ar' ? 'هل استلمت الطلب؟' : 'Have you received the order?', [
      { text: t('cancel'), style: 'cancel' },
      { text: t('confirm'), onPress: async () => { await markSelfPickupDelivered(order.id); Alert.alert(t('success'), locale === 'ar' ? 'تم تأكيد الاستلام' : 'Pickup confirmed'); } },
    ]);
  }, [order, markSelfPickupDelivered, t, locale]);

  const handleSubmitProviderRating = useCallback(async () => {
    if (!order || !user || providerStars === 0) { Alert.alert(t('error'), locale === 'ar' ? 'يرجى اختيار عدد النجوم' : 'Please select a rating'); return; }
    setIsSubmitting(true);
    try { await submitRating({ providerUid: order.providerUid, customerUid: user.uid, orderId: order.id, stars: providerStars, comment: providerComment.trim() }); Alert.alert(t('success'), t('ratingSubmitted')); }
    catch { Alert.alert(t('error'), t('error')); }
    finally { setIsSubmitting(false); }
  }, [order, user, providerStars, providerComment, submitRating, t, locale]);

  const handleSubmitDriverRating = useCallback(async () => {
    if (!order || !user || !order.driverUid || driverStars === 0) { Alert.alert(t('error'), locale === 'ar' ? 'يرجى اختيار عدد النجوم' : 'Please select a rating'); return; }
    setIsSubmitting(true);
    try { await submitDriverRating({ driverUid: order.driverUid, customerUid: user.uid, orderId: order.id, stars: driverStars, comment: driverComment.trim() }); Alert.alert(t('success'), t('ratingSubmitted')); }
    catch { Alert.alert(t('error'), t('error')); }
    finally { setIsSubmitting(false); }
  }, [order, user, driverStars, driverComment, submitDriverRating, t, locale]);

  if (!order) {
    return (<SafeAreaView style={cs.centerSafe}><Text>{t('error')}</Text></SafeAreaView>);
  }

  const paymentColors = getPaymentMethodColor(order.paymentMethod);
  const getPaymentLabel = () => {
    if (order.paymentMethod === 'stc_pay') return t('stcPay');
    if (order.paymentMethod === 'bank_transfer') return t('bankTransfer');
    return t('cashOnDelivery');
  };

  const r = isRTL;

  return (
    <View style={cs.container}>
      <SafeAreaView edges={['top']} style={cs.headerSafe}>
        <View style={[cs.header, r && cs.headerRTL]}>
          <Pressable style={cs.backBtn} onPress={() => router.back()}><BackIcon size={22} color={Colors.text} /></Pressable>
          <Text style={[cs.headerTitle, r && cs.rtlText]}>{t('orderDetails')}</Text>
          <View style={cs.backBtn} />
        </View>
      </SafeAreaView>

      <ScrollView style={cs.flex1} showsVerticalScrollIndicator={false}>
        <View style={cs.card}>
          {order.orderNumber ? <View style={[cs.cardRow, r && cs.rowRTL]}><Text style={[cs.label, r && cs.rtlText]}>{t('orderNumber')}</Text><Text style={cs.orderNumber}>{order.orderNumber}</Text></View> : null}
          <View style={[cs.cardRow, r && cs.rowRTL]}><Text style={[cs.label, r && cs.rtlText]}>{t('statusLabel')}</Text><OrderStatusBadge status={order.status} /></View>
          <View style={cs.divider} />
          <Text style={[cs.dishTitle, r && cs.rtlText]}>{order.offerTitleSnapshot}</Text>
          {provider ? <Text style={[s.providerName, r && cs.rtlText]}>{t('orderFrom')}: {provider.displayName}</Text> : null}
          <View style={cs.divider} />
          <View style={[cs.cardRow, r && cs.rowRTL]}><Text style={[cs.label, r && cs.rtlText]}>{t('foodPrice')}</Text><Text style={cs.priceValue}>{formatPrice(order.priceSnapshot, locale)}</Text></View>
          {order.deliveryMethod ? <View style={[cs.cardRow, r && cs.rowRTL]}><Text style={[cs.label, r && cs.rtlText]}>{t('deliveryFee')}</Text><Text style={cs.dateValue}>{order.deliveryFee === 0 ? t('free') : formatPrice(order.deliveryFee, locale)}</Text></View> : null}
          <View style={[cs.cardRow, r && cs.rowRTL]}><Text style={[cs.totalLabel, r && cs.rtlText]}>{t('totalAmount')}</Text><Text style={cs.totalValue}>{formatPrice(order.totalAmount, locale)}</Text></View>
          <View style={cs.divider} />
          <View style={[cs.cardRow, r && cs.rowRTL]}>
            <Text style={[cs.label, r && cs.rtlText]}>{t('paymentMethod')}</Text>
            <View style={[cs.paymentBadge, { backgroundColor: paymentColors.bg }]}>
              {order.paymentMethod === 'stc_pay' ? <CreditCard size={14} color={paymentColors.text} /> : order.paymentMethod === 'bank_transfer' ? <Building2 size={14} color={paymentColors.text} /> : <Banknote size={14} color={paymentColors.text} />}
              <Text style={[cs.paymentBadgeText, { color: paymentColors.text }]}>{getPaymentLabel()}</Text>
            </View>
          </View>
          {order.deliveryMethod ? <View style={[cs.cardRow, r && cs.rowRTL]}><Text style={[cs.label, r && cs.rtlText]}>{t('deliveryMethod')}</Text><Text style={cs.dateValue}>{order.deliveryMethod === 'self_pickup' ? t('selfPickup') : t('driverDelivery')}</Text></View> : null}
          <View style={[cs.cardRow, r && cs.rowRTL]}><Text style={[cs.label, r && cs.rtlText]}>{t('orderedOn')}</Text><Text style={cs.dateValue}>{formatDate(order.createdAt, locale)}</Text></View>
          {order.note ? <><View style={cs.divider} /><Text style={[cs.label, r && cs.rtlText]}>{t('noteLabel')}</Text><Text style={[cs.noteText, r && cs.rtlText]}>{order.note}</Text></> : null}
          {order.providerComment ? <><View style={cs.divider} /><Text style={[cs.label, r && cs.rtlText]}>{t('providerNote')}</Text><Text style={[cs.noteText, r && cs.rtlText]}>{order.providerComment}</Text></> : null}
        </View>

        {order.paymentStatus !== 'unpaid' && order.paymentStatus !== 'paid' && (
          <View style={cs.sectionCard}>
            <View style={[cs.cardRow, r && cs.rowRTL]}>
              <Text style={[cs.label, r && cs.rtlText]}>{t('paymentStatus')}</Text>
              {(() => { const psC = getPaymentStatusColor(order.paymentStatus); return (
                <View style={[cs.statusBadge, { backgroundColor: psC.bg }]}>
                  {order.paymentStatus === 'proof_sent' && <FileCheck size={14} color={psC.text} />}
                  {order.paymentStatus === 'paid_confirmed' && <CheckCircle2 size={14} color={psC.text} />}
                  {order.paymentStatus === 'payment_rejected' && <XCircle size={14} color={psC.text} />}
                  <Text style={[cs.statusBadgeText, { color: psC.text }]}>{t(order.paymentStatus as any)}</Text>
                </View>); })()}
            </View>
            {hasProofSent && <Text style={[s.proofDesc, { color: Colors.info }]}>{t('proofSentDesc')}</Text>}
            {isPaymentRejected && <Text style={[s.proofDesc, { color: Colors.error }]}>{locale === 'ar' ? 'تم رفض الإثبات من الطباخ. يرجى إعادة الإرسال.' : 'Proof rejected by the chef. Please resend.'}</Text>}
          </View>
        )}

        {(canSubmitProof || isPaymentRejected) && (
          <View style={cs.sectionCard}>
            <Text style={[cs.sectionTitle, r && cs.rtlText]}>{t('paymentProof')}</Text>
            <Pressable style={({ pressed }) => [s.whatsappBtn, pressed && cs.btnPressed]} onPress={handleWhatsAppProof}>
              <MessageCircle size={20} color="#FFFFFF" /><Text style={s.whatsappText}>{t('sendProofViaWhatsapp')}</Text>
            </Pressable>
            <Pressable style={({ pressed }) => [s.uploadToggle, pressed && cs.btnPressed]} onPress={() => setShowPaymentProof(!showPaymentProof)}>
              <Upload size={18} color={Colors.primary} /><Text style={s.uploadText}>{t('sendPaymentProof')}</Text>
            </Pressable>
            {showPaymentProof && (
              <View style={s.proofForm}>
                <Text style={[cs.formLabel, r && cs.rtlText]}>{t('proofImageUrl')}</Text>
                <TextInput style={[cs.formInput, r && cs.inputRTL]} placeholder={t('proofImageUrlHint')} placeholderTextColor={Colors.textTertiary} value={proofImageUrl} onChangeText={setProofImageUrl} textAlign={r ? 'right' : 'left'} keyboardType="url" />
                <Text style={[cs.formLabel, r && cs.rtlText]}>{t('proofNote')}</Text>
                <TextInput style={[cs.formInput, r && cs.inputRTL]} placeholder={t('proofNoteHint')} placeholderTextColor={Colors.textTertiary} value={proofNote} onChangeText={setProofNote} textAlign={r ? 'right' : 'left'} multiline numberOfLines={2} textAlignVertical="top" />
                <Text style={[cs.formLabel, r && cs.rtlText]}>{t('paymentReferenceLabel')}</Text>
                <TextInput style={[cs.formInput, r && cs.inputRTL]} placeholder={t('paymentReferenceHint')} placeholderTextColor={Colors.textTertiary} value={paymentRef} onChangeText={setPaymentRef} textAlign={r ? 'right' : 'left'} />
                <Pressable style={({ pressed }) => [cs.primaryBtn, { marginTop: 12 }, pressed && cs.btnPressed]} onPress={handleSubmitPaymentProof} disabled={isSubmitting}>
                  <Text style={cs.primaryBtnText}>{t('sendPaymentProof')}</Text>
                </Pressable>
              </View>
            )}
          </View>
        )}

        {(order.paymentMethod === 'stc_pay' || order.paymentMethod === 'bank_transfer') && provider && order.status !== 'rejected' && order.status !== 'cancelled' && (
          <View style={cs.sectionCard}>
            <Text style={[cs.sectionTitle, r && cs.rtlText]}>{t('paymentInstructions')}</Text>
            {order.paymentMethod === 'stc_pay' && provider.paymentMethods?.stcPay?.enabled && (
              <View style={s.payDetail}>
                <Text style={[s.payDetailLabel, r && cs.rtlText]}>{t('stcPayPhone')}</Text>
                <View style={[s.copyRow, r && cs.rowRTL]}>
                  <Text style={s.payDetailValue}>{provider.paymentMethods.stcPay.phone}</Text>
                  <Pressable style={s.copyBtn} onPress={() => handleCopy(provider.paymentMethods?.stcPay?.phone ?? '')}>
                    <Copy size={14} color={Colors.primary} /><Text style={s.copyText}>{t('copyToClipboard')}</Text>
                  </Pressable>
                </View>
              </View>
            )}
            {order.paymentMethod === 'bank_transfer' && provider.paymentMethods?.bankTransfer?.enabled && (
              <>
                <View style={s.payDetail}><Text style={[s.payDetailLabel, r && cs.rtlText]}>{t('bankName')}</Text><Text style={[s.payDetailValue, r && cs.rtlText]}>{provider.paymentMethods.bankTransfer.bankName}</Text></View>
                <View style={s.payDetail}><Text style={[s.payDetailLabel, r && cs.rtlText]}>{t('accountName')}</Text><Text style={[s.payDetailValue, r && cs.rtlText]}>{provider.paymentMethods.bankTransfer.accountName}</Text></View>
                <View style={s.payDetail}>
                  <Text style={[s.payDetailLabel, r && cs.rtlText]}>{t('iban')}</Text>
                  <View style={[s.copyRow, r && cs.rowRTL]}>
                    <Text style={s.payDetailValue} numberOfLines={1}>{provider.paymentMethods.bankTransfer.iban}</Text>
                    <Pressable style={s.copyBtn} onPress={() => handleCopy(provider.paymentMethods?.bankTransfer?.iban ?? '')}>
                      <Copy size={14} color={Colors.primary} /><Text style={s.copyText}>{t('copyToClipboard')}</Text>
                    </Pressable>
                  </View>
                </View>
              </>
            )}
            <Text style={[s.payNote, r && cs.rtlText]}>{t('paymentNote')}</Text>
          </View>
        )}

        {canChooseDelivery && (
          <View style={cs.sectionCard}>
            <Text style={[cs.sectionTitle, r && cs.rtlText]}>{t('chooseDeliveryMethod')}</Text>
            <Pressable style={({ pressed }) => [s.deliveryOpt, pressed && cs.btnPressed]} onPress={handleSelfPickup}>
              <View style={[s.deliveryContent, r && cs.rowRTL]}>
                <View style={[s.deliveryIcon, { backgroundColor: Colors.deliveredBg }]}><PackageCheck size={22} color={Colors.delivered} /></View>
                <View style={cs.flex1}><Text style={[s.deliveryTitle, r && cs.rtlText]}>{t('selfPickup')}</Text><Text style={[s.deliveryDesc, r && cs.rtlText]}>{t('selfPickupDesc')}</Text></View>
                <Text style={s.deliveryFee}>{t('free')}</Text>
              </View>
            </Pressable>
            <Pressable style={({ pressed }) => [s.deliveryOpt, pressed && cs.btnPressed]} onPress={() => order && setShowDriverSelection(true)}>
              <View style={[s.deliveryContent, r && cs.rowRTL]}>
                <View style={[s.deliveryIcon, { backgroundColor: Colors.assignedToDriverBg }]}><Truck size={22} color={Colors.assignedToDriver} /></View>
                <View style={cs.flex1}><Text style={[s.deliveryTitle, r && cs.rtlText]}>{t('driverDelivery')}</Text><Text style={[s.deliveryDesc, r && cs.rtlText]}>{t('driverDeliveryDesc')}</Text></View>
                <Text style={s.deliveryFee}>~{formatPrice(estimatedFee, locale)}</Text>
              </View>
            </Pressable>
          </View>
        )}

        {showDriverSelection && (
          <View style={cs.sectionCard}>
            <Text style={[cs.sectionTitle, r && cs.rtlText]}>{t('availableDrivers')}</Text>
            {availableDrivers.length === 0 ? <Text style={[s.emptyText, r && cs.rtlText]}>{t('noAvailableDrivers')}</Text> : availableDrivers.map((d) => {
              const dist = provider?.location && d.location ? calculateDistance(provider.location.lat, provider.location.lng, d.location.lat, d.location.lng) : null;
              return (
                <Pressable key={d.uid} style={({ pressed }) => [s.driverCard, pressed && cs.btnPressed]} onPress={() => handleSelectDriver(d)}>
                  <View style={[cs.driverRow, r && cs.rowRTL]}>
                    <View style={cs.driverIconWrap}><Truck size={20} color={Colors.primary} /></View>
                    <View style={cs.flex1}>
                      <Text style={[s.driverName, r && cs.rtlText]}>{d.displayName}</Text>
                      <View style={[s.driverMeta, r && cs.rowRTL]}>
                        <Star size={12} color={Colors.star} /><Text style={s.driverRating}>{d.ratingAverage?.toFixed(1) || '0.0'}</Text>
                        {dist !== null && <Text style={s.driverDist}> • {formatDistance(dist, locale)}</Text>}
                      </View>
                    </View>
                    <Pressable style={s.selectBtn} onPress={() => handleSelectDriver(d)}><Text style={s.selectText}>{t('selectDriver')}</Text></Pressable>
                  </View>
                </Pressable>
              );
            })}
          </View>
        )}

        {order.deliveryMethod === 'self_pickup' && order.status === 'ready_for_pickup' && (
          <Pressable style={({ pressed }) => [s.pickupBtn, pressed && cs.btnPressed]} onPress={handleSelfPickupDelivered}>
            <PackageCheck size={20} color={Colors.white} /><Text style={cs.actionBtnText}>{locale === 'ar' ? 'تأكيد الاستلام' : 'Confirm Pickup'}</Text>
          </Pressable>
        )}

        {driver && (
          <View style={cs.sectionCard}>
            <Text style={[cs.sectionTitle, r && cs.rtlText]}>{t('deliveryInfo')}</Text>
            <View style={[cs.driverRow, r && cs.rowRTL]}>
              <View style={cs.driverIconWrap}><Truck size={20} color={Colors.primary} /></View>
              <View style={cs.flex1}>
                <Text style={[s.driverName, r && cs.rtlText]}>{driver.displayName}</Text>
                <View style={[s.driverMeta, r && cs.rowRTL]}><Phone size={12} color={Colors.textTertiary} /><Text style={s.driverDist}>{driver.phone}</Text></View>
              </View>
              <View style={{ alignItems: 'center' as const }}><Text style={s.driverRatingBig}>{driver.ratingAverage?.toFixed(1) || '0.0'}</Text><Text style={{ fontSize: 12 }}>⭐</Text></View>
            </View>
          </View>
        )}

        {canRateProvider && (
          <View style={cs.sectionCard}>
            <Text style={[s.ratingTitle, r && cs.rtlText]}>{t('rateProvider')}</Text>
            <View style={s.starsRow}><RatingStars rating={providerStars} size={32} interactive onRate={setProviderStars} /></View>
            <TextInput style={[s.ratingInput, r && cs.inputRTL]} placeholder={t('ratingCommentHint')} placeholderTextColor={Colors.textTertiary} value={providerComment} onChangeText={setProviderComment} multiline numberOfLines={3} textAlignVertical="top" textAlign={r ? 'right' : 'left'} />
            <Pressable style={({ pressed }) => [cs.primaryBtn, pressed && cs.btnPressed]} onPress={handleSubmitProviderRating} disabled={isSubmitting}><Text style={cs.primaryBtnText}>{t('submitRating')}</Text></Pressable>
          </View>
        )}

        {canRateDriver && (
          <View style={cs.sectionCard}>
            <Text style={[s.ratingTitle, r && cs.rtlText]}>{t('rateDriver')}</Text>
            <View style={s.starsRow}><RatingStars rating={driverStars} size={32} interactive onRate={setDriverStars} /></View>
            <TextInput style={[s.ratingInput, r && cs.inputRTL]} placeholder={t('ratingCommentHint')} placeholderTextColor={Colors.textTertiary} value={driverComment} onChangeText={setDriverComment} multiline numberOfLines={3} textAlignVertical="top" textAlign={r ? 'right' : 'left'} />
            <Pressable style={({ pressed }) => [cs.primaryBtn, { backgroundColor: Colors.info }, pressed && cs.btnPressed]} onPress={handleSubmitDriverRating} disabled={isSubmitting}><Text style={cs.primaryBtnText}>{t('submitRating')}</Text></Pressable>
          </View>
        )}

        <View style={cs.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  providerName: { fontSize: 14, color: Colors.textSecondary },
  proofDesc: { fontSize: 13, marginTop: 10, lineHeight: 18 },
  whatsappBtn: { flexDirection: 'row', backgroundColor: '#25D366', height: 50, borderRadius: 14, justifyContent: 'center', alignItems: 'center', gap: 10, marginBottom: 12 },
  whatsappText: { color: Colors.white, fontSize: 16, fontWeight: '700' as const },
  uploadToggle: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12, borderRadius: 14, borderWidth: 2, borderColor: Colors.primary },
  uploadText: { fontSize: 15, fontWeight: '600' as const, color: Colors.primary },
  proofForm: { marginTop: 16 },
  payDetail: { marginBottom: 12 },
  payDetailLabel: { fontSize: 12, color: Colors.textTertiary, marginBottom: 4 },
  payDetailValue: { fontSize: 15, fontWeight: '600' as const, color: Colors.text, flex: 1 },
  copyRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  copyBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.primaryFaded, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  copyText: { fontSize: 12, color: Colors.primary, fontWeight: '600' as const },
  payNote: { fontSize: 12, color: Colors.textTertiary, marginTop: 4, lineHeight: 18 },
  deliveryOpt: { backgroundColor: Colors.background, borderRadius: 16, padding: 16, marginBottom: 10, borderWidth: 2, borderColor: Colors.borderLight },
  deliveryContent: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  deliveryIcon: { width: 48, height: 48, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  deliveryTitle: { fontSize: 15, fontWeight: '700' as const, color: Colors.text, marginBottom: 2 },
  deliveryDesc: { fontSize: 12, color: Colors.textTertiary },
  deliveryFee: { fontSize: 14, fontWeight: '700' as const, color: Colors.primary },
  emptyText: { fontSize: 14, color: Colors.textTertiary, textAlign: 'center', paddingVertical: 20 },
  driverCard: { backgroundColor: Colors.background, borderRadius: 14, padding: 14, marginBottom: 10 },
  driverName: { fontSize: 16, fontWeight: '700' as const, color: Colors.text, marginBottom: 4 },
  driverMeta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  driverRating: { fontSize: 12, color: Colors.textSecondary, fontWeight: '600' as const },
  driverDist: { fontSize: 12, color: Colors.textTertiary },
  driverRatingBig: { fontSize: 16, fontWeight: '700' as const, color: Colors.text },
  selectBtn: { backgroundColor: Colors.primary, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10 },
  selectText: { color: Colors.white, fontSize: 13, fontWeight: '700' as const },
  pickupBtn: { flexDirection: 'row', backgroundColor: Colors.delivered, height: 54, borderRadius: 16, justifyContent: 'center', alignItems: 'center', gap: 10, marginHorizontal: 20, marginBottom: 16 },
  ratingTitle: { fontSize: 18, fontWeight: '700' as const, color: Colors.text, marginBottom: 16 },
  starsRow: { alignItems: 'center', marginBottom: 16 },
  ratingInput: { backgroundColor: Colors.background, borderRadius: 14, padding: 16, fontSize: 14, color: Colors.text, minHeight: 80, marginBottom: 16, borderWidth: 1, borderColor: Colors.borderLight },
});

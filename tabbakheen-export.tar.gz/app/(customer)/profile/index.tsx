import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import {
  LogOut,
  Globe,
  Mail,
  Phone,
  MapPin,
  ChevronLeft,
  ChevronRight,
  UserCircle,
  Shield,
  Info,
} from 'lucide-react-native';
import Colors from '@/constants/colors';
import { useLocale } from '@/contexts/LocaleContext';
import { useAuth } from '@/contexts/AuthContext';
import SupportDialog from '@/components/SupportDialog';

export default function CustomerProfileScreen() {
  const router = useRouter();
  const { t, isRTL, locale, toggleLocale } = useLocale();
  const { user, logout } = useAuth();

  const Arrow = isRTL ? ChevronLeft : ChevronRight;
  const [showSupport, setShowSupport] = useState<boolean>(false);

  const handleLogout = useCallback(() => {
    Alert.alert(
      t('logout'),
      locale === 'ar' ? 'هل أنت متأكد من تسجيل الخروج؟' : 'Are you sure you want to logout?',
      [
        { text: t('cancel'), style: 'cancel' },
        {
          text: t('logout'),
          style: 'destructive',
          onPress: async () => {
            await logout();
            router.replace('/auth/login' as any);
          },
        },
      ],
    );
  }, [logout, t, locale]);

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.headerSafe}>
        <Text style={[styles.headerTitle, isRTL && styles.rtlText]}>{t('profile')}</Text>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.profileSection}>
          <View style={styles.avatarContainer}>
            {user?.photoUrl ? (
              <Image source={{ uri: user.photoUrl }} style={styles.avatar} contentFit="cover" />
            ) : (
              <View style={[styles.avatar, styles.avatarPlaceholder]}>
                <UserCircle size={48} color={Colors.primary} />
              </View>
            )}
          </View>
          <Text style={[styles.name, isRTL && styles.rtlText]}>{user?.displayName}</Text>
          <Text style={[styles.role, isRTL && styles.rtlText]}>{t('customer')}</Text>
        </View>

        <View style={styles.infoSection}>
          <View style={[styles.infoRow, isRTL && styles.rowRTL]}>
            <Mail size={18} color={Colors.textTertiary} />
            <Text style={[styles.infoText, isRTL && styles.rtlText]}>{user?.email}</Text>
          </View>
          {user?.phone ? (
            <View style={[styles.infoRow, isRTL && styles.rowRTL]}>
              <Phone size={18} color={Colors.textTertiary} />
              <Text style={[styles.infoText, isRTL && styles.rtlText]}>{user.phone}</Text>
            </View>
          ) : null}
          {user?.address ? (
            <View style={[styles.infoRow, isRTL && styles.rowRTL]}>
              <MapPin size={18} color={Colors.textTertiary} />
              <Text style={[styles.infoText, isRTL && styles.rtlText]}>{user.address}</Text>
            </View>
          ) : null}
        </View>

        <View style={styles.menuSection}>
          <Pressable
            style={({ pressed }) => [styles.menuItem, isRTL && styles.rowRTL, pressed && styles.menuPressed]}
            onPress={toggleLocale}
          >
            <Globe size={20} color={Colors.primary} />
            <Text style={[styles.menuText, isRTL && styles.rtlText, styles.menuTextFlex]}>{t('language')}</Text>
            <Text style={styles.menuValue}>{locale === 'ar' ? t('arabic') : t('english')}</Text>
            <Arrow size={18} color={Colors.textTertiary} />
          </Pressable>

          <Pressable
            style={({ pressed }) => [styles.menuItem, isRTL && styles.rowRTL, pressed && styles.menuPressed]}
            onPress={() => router.push('/(customer)/profile/about' as any)}
          >
            <Info size={20} color={Colors.primary} />
            <Text style={[styles.menuText, isRTL && styles.rtlText, styles.menuTextFlex]}>{t('aboutTitle')}</Text>
            <Arrow size={18} color={Colors.textTertiary} />
          </Pressable>

          <Pressable
            style={({ pressed }) => [styles.menuItem, isRTL && styles.rowRTL, pressed && styles.menuPressed]}
            onPress={() => setShowSupport(true)}
          >
            <Shield size={20} color={Colors.primary} />
            <Text style={[styles.menuText, isRTL && styles.rtlText, styles.menuTextFlex]}>{t('supportTitle')}</Text>
            <Arrow size={18} color={Colors.textTertiary} />
          </Pressable>
        </View>

        <Pressable
          style={({ pressed }) => [styles.logoutBtn, pressed && styles.logoutPressed]}
          onPress={handleLogout}
        >
          <LogOut size={20} color={Colors.error} />
          <Text style={styles.logoutText}>{t('logout')}</Text>
        </Pressable>

        <Text style={styles.versionText}>
          {t('version')} 1.0.0 • {t('poweredBy')}
        </Text>

        <View style={styles.bottomSpacer} />
      </ScrollView>

      <SupportDialog visible={showSupport} onClose={() => setShowSupport(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  headerSafe: {
    backgroundColor: Colors.surface,
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '800' as const,
    color: Colors.text,
    marginTop: 8,
  },
  profileSection: {
    alignItems: 'center',
    backgroundColor: Colors.surface,
    paddingBottom: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 20,
  },
  avatarContainer: {
    marginBottom: 12,
  },
  avatar: {
    width: 88,
    height: 88,
    borderRadius: 44,
  },
  avatarPlaceholder: {
    backgroundColor: Colors.primaryFaded,
    justifyContent: 'center',
    alignItems: 'center',
  },
  name: {
    fontSize: 22,
    fontWeight: '800' as const,
    color: Colors.text,
    marginBottom: 4,
  },
  role: {
    fontSize: 14,
    color: Colors.textSecondary,
    fontWeight: '500' as const,
  },
  infoSection: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    marginHorizontal: 20,
    padding: 16,
    marginBottom: 20,
    gap: 14,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  rowRTL: {
    flexDirection: 'row-reverse',
  },
  infoText: {
    fontSize: 15,
    color: Colors.text,
    flex: 1,
  },
  menuSection: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    marginHorizontal: 20,
    marginBottom: 20,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 14,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  menuPressed: {
    backgroundColor: Colors.background,
  },
  menuText: {
    fontSize: 15,
    fontWeight: '600' as const,
    color: Colors.text,
  },
  menuTextFlex: {
    flex: 1,
  },
  menuValue: {
    fontSize: 13,
    color: Colors.textTertiary,
    marginRight: 4,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.errorLight,
    borderRadius: 14,
    marginHorizontal: 20,
    padding: 16,
    gap: 10,
  },
  logoutPressed: {
    opacity: 0.9,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '700' as const,
    color: Colors.error,
  },
  versionText: {
    textAlign: 'center',
    fontSize: 12,
    color: Colors.textTertiary,
    marginTop: 24,
  },
  bottomSpacer: {
    height: 30,
  },
  rtlText: {
    textAlign: 'right',
    writingDirection: 'rtl',
  },
});

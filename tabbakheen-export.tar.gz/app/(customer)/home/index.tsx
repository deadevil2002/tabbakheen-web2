import React, { useState, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Pressable,
  FlatList,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { Search, Globe, Star, ChevronLeft, ChevronRight } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { useLocale } from '@/contexts/LocaleContext';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { OfferCard } from '@/components/OfferCard';
import { Offer } from '@/types';
import { formatPrice } from '@/utils/helpers';
import { MOCK_APP_SETTINGS } from '@/mocks/data';

export default function CustomerHomeScreen() {
  const router = useRouter();
  const { t, isRTL, locale, toggleLocale } = useLocale();
  const { user } = useAuth();
  const { availableOffers, providers, isLoading } = useData();

  const [search, setSearch] = useState<string>('');
  const [refreshing, setRefreshing] = useState<boolean>(false);

  const filteredOffers = useMemo(() => {
    if (!search.trim()) return availableOffers;
    const q = search.toLowerCase();
    return availableOffers.filter(
      (o) => o.title.toLowerCase().includes(q) || o.description.toLowerCase().includes(q),
    );
  }, [availableOffers, search]);

  const getProvider = useCallback(
    (uid: string) => providers.find((p) => p.uid === uid),
    [providers],
  );

  const handleOfferPress = useCallback(
    (offer: Offer) => {
      router.push(`/(customer)/home/offer/${offer.id}` as any);
    },
    [],
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 800);
  }, []);

  const Arrow = isRTL ? ChevronLeft : ChevronRight;

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.safeTop}>
        <View style={[styles.header, isRTL && styles.headerRTL]}>
          <View style={styles.headerLeft}>
            <Text style={[styles.greeting, isRTL && styles.rtlText]}>
              {t('welcome')} 👋
            </Text>
            <Text style={[styles.userName, isRTL && styles.rtlText]}>
              {user?.displayName || ''}
            </Text>
          </View>
          <Pressable style={styles.langBtn} onPress={toggleLocale}>
            <Globe size={18} color={Colors.textSecondary} />
          </Pressable>
        </View>

        <View style={[styles.searchContainer, isRTL && styles.searchContainerRTL]}>
          <Search size={20} color={Colors.textTertiary} />
          <TextInput
            style={[styles.searchInput, isRTL && styles.inputRTL]}
            placeholder={t('searchOffers')}
            placeholderTextColor={Colors.textTertiary}
            value={search}
            onChangeText={setSearch}
            textAlign={isRTL ? 'right' : 'left'}
            testID="home-search"
          />
        </View>
      </SafeAreaView>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />
        }
      >
        <View style={styles.bannerContainer}>
          <Image
            source={{ uri: MOCK_APP_SETTINGS.bannerImageUrl }}
            style={styles.bannerImage}
            contentFit="cover"
          />
          <View style={styles.bannerOverlay}>
            <Text style={styles.bannerTitle}>{t('appName')}</Text>
            <Text style={styles.bannerSubtitle}>{t('appTagline')}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <View style={[styles.sectionHeader, isRTL && styles.sectionHeaderRTL]}>
            <Text style={[styles.sectionTitle, isRTL && styles.rtlText]}>
              {t('nearbyProviders')}
            </Text>
            <Pressable
              style={[styles.seeAllBtn, isRTL && styles.seeAllBtnRTL]}
              onPress={() => router.push('/(customer)/map' as any)}
            >
              <Text style={styles.seeAllText}>{t('map')}</Text>
              <Arrow size={16} color={Colors.primary} />
            </Pressable>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.providersScroll}
          >
            {providers.map((provider) => (
              <Pressable
                key={provider.uid}
                style={({ pressed }) => [styles.providerChip, pressed && styles.chipPressed]}
                onPress={() => router.push(`/(customer)/home/provider/${provider.uid}` as any)}
              >
                <Image
                  source={{ uri: provider.photoUrl }}
                  style={styles.providerChipAvatar}
                  contentFit="cover"
                />
                <Text style={styles.providerChipName} numberOfLines={1}>
                  {provider.displayName}
                </Text>
                <View style={styles.providerChipRating}>
                  <Star size={10} color={Colors.star} fill={Colors.star} />
                  <Text style={styles.providerChipRatingText}>
                    {provider.ratingAverage.toFixed(1)}
                  </Text>
                </View>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isRTL && styles.rtlText, styles.sectionTitlePadded]}>
            {t('allOffers')}
          </Text>
          <View style={styles.offersGrid}>
            {filteredOffers.map((offer) => (
              <OfferCard
                key={offer.id}
                offer={offer}
                provider={getProvider(offer.providerUid)}
                onPress={handleOfferPress}
              />
            ))}
          </View>
          {filteredOffers.length === 0 && (
            <Text style={[styles.emptyText, isRTL && styles.rtlText]}>{t('noOffers')}</Text>
          )}
        </View>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  safeTop: {
    backgroundColor: Colors.surface,
    paddingBottom: 12,
    shadowColor: Colors.shadow.color,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    zIndex: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 12,
  },
  headerRTL: {
    flexDirection: 'row-reverse',
  },
  headerLeft: {
    flex: 1,
  },
  greeting: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  userName: {
    fontSize: 22,
    fontWeight: '800' as const,
    color: Colors.text,
  },
  langBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    backgroundColor: Colors.background,
    borderRadius: 14,
    paddingHorizontal: 16,
    height: 46,
    gap: 10,
  },
  searchContainerRTL: {
    flexDirection: 'row-reverse',
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: Colors.text,
    height: '100%',
  },
  inputRTL: {
    writingDirection: 'rtl',
  },
  scrollView: {
    flex: 1,
  },
  bannerContainer: {
    margin: 20,
    borderRadius: 20,
    overflow: 'hidden',
    height: 160,
  },
  bannerImage: {
    width: '100%',
    height: '100%',
  },
  bannerOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
    padding: 20,
  },
  bannerTitle: {
    fontSize: 26,
    fontWeight: '800' as const,
    color: Colors.white,
    marginBottom: 4,
  },
  bannerSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.85)',
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 14,
  },
  sectionHeaderRTL: {
    flexDirection: 'row-reverse',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700' as const,
    color: Colors.text,
  },
  sectionTitlePadded: {
    paddingHorizontal: 20,
    marginBottom: 14,
  },
  seeAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  seeAllBtnRTL: {
    flexDirection: 'row-reverse',
  },
  seeAllText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '600' as const,
  },
  providersScroll: {
    paddingHorizontal: 20,
  },
  providerChip: {
    width: 90,
    alignItems: 'center',
    marginRight: 14,
  },
  chipPressed: {
    opacity: 0.8,
  },
  providerChipAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginBottom: 8,
    borderWidth: 2,
    borderColor: Colors.primaryFaded,
  },
  providerChipName: {
    fontSize: 12,
    fontWeight: '600' as const,
    color: Colors.text,
    textAlign: 'center',
    marginBottom: 4,
  },
  providerChipRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  providerChipRatingText: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontWeight: '600' as const,
  },
  offersGrid: {
    paddingHorizontal: 20,
  },
  emptyText: {
    fontSize: 15,
    color: Colors.textTertiary,
    textAlign: 'center',
    paddingVertical: 40,
  },
  bottomSpacer: {
    height: 20,
  },
  rtlText: {
    textAlign: 'right',
    writingDirection: 'rtl',
  },
});
